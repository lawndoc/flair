Malwareswaldo: C.J. May, Nick Sanford

New to Project 6:
    - Made tm-debug to help debug TM programs (some full paths need modified
        to run)
    - Updated src/generator.py but most of the heavy lifting goes on
        in src/AST.py with the genCode() method for each node
    - Made lots of test files to test features of language
    - Made a "late CS1 program" named "sum-of-primes.flr" that will
        add all of the prime numbers less than the maximum number inputted
        by the user. This was a solution to one of the Euler Project Problems
        (Problem 10) to find the sum of all primes below 2 million.

Known Bugs:

Features Not Implemented:
    - Compiler doesn't track which line of code an error occurred on.
    - Can't yet generate print statements.

Optimizations:
    - Scanner: We combined multiple states when possibly reading a word reserved
        by the flair language. We did this by keeping a list of remaining
        letters and popping off letters from that list as they were read. This
        reduces the number of if/elif checks and the length of the overall
        scanner file.
    - Analyzer: The analyze function for the AST nodes annotates node types and
        builds the symbol table simultaneously. This way the AST only needs to be
        traversed once for analysis, and each node is only visited once (except
        for function nodes while building the initial symbol table).

How To Run:
    To test the scanner, use one of these three ways:
        - call flairs from the command line, passing in an argument for a flair
            program (ex. $ flairs /path/to/program.flr )
        - call scantest.py from from the command line, passing in an argument
            for a flair program (ex. $ scantest.py /path/to/program.flr )
        - call scantest.py with python3 from the command line, passing in an
            argument for a flair program
            (ex. python3 scantest.py /path/to/program.flr )

    To test the validity of a program with the parser, use one of these three ways:
        - call flairf from the command line, passing in an argument for a flair
            program (ex. $ flairf /path/to/program.flr )
        - call parsetest.py from from the command line, passing in an argument
            for a flair program (ex. $ parsetest.py /path/to/program.flr )
        - call parsetest.py with python3 from the command line, passing in an
            argument for a flair program
            (ex. python3 parsetest.py /path/to/program.flr )

    To test the AST of a program with the parser, use one of these three ways:
        - call flairp from the command line, passing in an argument for a flair
            program (ex. $ flairp /path/to/program.flr )
        - call parsetest_ast.py from from the command line, passing in an argument
            for a flair program (ex. $ parsetest_ast.py /path/to/program.flr )
        - call parsetest_ast.py with python3 from the command line, passing in an
            argument for a flair program
            (ex. python3 parsetest_ast.py /path/to/program.flr )

    To do semantic analysis on a program with the analyzer, use one of these three ways:
        - call flairv from the command line, passing in an argument for a flair
            program (ex. $ flairv /path/to/program.flr )
        - call analyzertest.py from from the command line, passing in an argument
            for a flair program (ex. $ analyzertest.py /path/to/program.flr )
        - call analyzertest.py with python3 from the command line, passing in an
            argument for a flair program
            (ex. python3 analyzertest.py /path/to/program.flr )

    To compile a program with the generator, use one of these three ways:
        - call flairc from the command line, passing in an argument for a flair
            program (ex. $ flairc /path/to/program.flr )
        - call generatortest.py from from the command line, passing in an argument
            for a flair program (ex. $ generatortest.py /path/to/program.flr )
        - call generatortest.py with python3 from the command line, passing in an
            argument for a flair program
            (ex. python3 generatortest.py /path/to/program.flr )
